package uk.gov.openinnovation.watfordmetwidget;
/** Kept for older installed widgets from v0.5. New installs use WatfordMetWidgetProvider. */
public class TrainWidgetProvider extends WatfordMetWidgetProvider { }
