package uk.gov.openinnovation.watfordmetwidget;
public class WatfordMetWidgetProvider extends BaseTrainWidgetProvider { protected String routeId(){return TflClient.ROUTE_WATFORD;} protected Class<?> providerClass(){return WatfordMetWidgetProvider.class;} }
