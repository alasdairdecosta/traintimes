package uk.gov.openinnovation.watfordmetwidget;
public class PeckhamToVictoriaWidgetProvider extends BaseTrainWidgetProvider { protected String routeId(){return TflClient.ROUTE_PMR_VIC;} protected Class<?> providerClass(){return PeckhamToVictoriaWidgetProvider.class;} }
