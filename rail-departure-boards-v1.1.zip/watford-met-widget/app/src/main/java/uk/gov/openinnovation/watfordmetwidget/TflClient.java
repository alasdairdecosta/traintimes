package uk.gov.openinnovation.watfordmetwidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

final class TflClient {
    static final String ROUTE_WATFORD = "watford_met";
    static final String ROUTE_PMR_VIC = "pmr_vic";
    static final String ROUTE_VIC_PMR = "vic_pmr";
    private static final String PREFS = "board_cache_v2";
    private static final long SOFT_THROTTLE_MS = 20_000L;

    static BoardSpec spec(String route) {
        if (ROUTE_PMR_VIC.equals(route)) return new BoardSpec(route, "PECKHAM RYE", "TO LONDON VICTORIA", "PMR", "VIC", false);
        if (ROUTE_VIC_PMR.equals(route)) return new BoardSpec(route, "VICTORIA", "TO PECKHAM RYE", "VIC", "PMR", false);
        return new BoardSpec(ROUTE_WATFORD, "WATFORD", "METROPOLITAN LINE  ·  SOUTHBOUND", "940GZZLUWAF", "", true);
    }

    static BoardData loadBoard(Context context, String route, boolean force) throws Exception {
        BoardSpec s = spec(route);
        BoardData cached = readCache(context, s.id);
        long now = System.currentTimeMillis();
        if (!force && cached != null && now - cached.fetchedAt < SOFT_THROTTLE_MS) return cached.withCachedFlag(false);
        if (!isOnline(context)) {
            if (cached != null) return cached.withCachedFlag(true);
            throw new Exception("No connection");
        }
        BoardData data = s.isTfl ? fetchWatford(s) : fetchNationalRail(s);
        writeCache(context, data);
        return data;
    }

    static BoardData readCache(Context context, String route) {
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String raw = p.getString(route, null);
            if (raw == null) return null;
            JSONObject o = new JSONObject(raw);
            BoardSpec s = spec(o.optString("route", route));
            JSONArray rows = o.getJSONArray("trains");
            List<Train> trains = new ArrayList<>();
            for (int i = 0; i < rows.length(); i++) {
                JSONObject r = rows.getJSONObject(i);
                trains.add(new Train(r.optInt("seconds"), r.optInt("minutes"), r.optString("destination"), r.optString("platform"), r.optString("currentLocation"), r.optString("scheduled")));
            }
            return new BoardData(s, trains, o.optString("status"), o.optLong("fetchedAt"), true, null);
        } catch (Exception ignored) { return null; }
    }

    private static void writeCache(Context context, BoardData data) {
        try {
            JSONObject o = new JSONObject();
            o.put("route", data.spec.id); o.put("status", data.status); o.put("fetchedAt", data.fetchedAt);
            JSONArray arr = new JSONArray();
            for (Train t : data.trains) {
                JSONObject r = new JSONObject();
                r.put("seconds", t.seconds); r.put("minutes", t.minutes); r.put("destination", t.destination);
                r.put("platform", t.platform); r.put("currentLocation", t.currentLocation); r.put("scheduled", t.scheduled); arr.put(r);
            }
            o.put("trains", arr);
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(data.spec.id, o.toString()).apply();
        } catch (Exception ignored) { }
    }

    private static BoardData fetchWatford(BoardSpec s) throws Exception {
        JSONArray arr = new JSONArray(get("https://api.tfl.gov.uk/StopPoint/940GZZLUWAF/Arrivals", "LondonRailBoard/1.0"));
        List<Train> result = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            if (!o.optString("lineName", "").toLowerCase(Locale.UK).contains("metropolitan")) continue;
            int seconds = o.optInt("timeToStation", 999999);
            if (seconds < -30) continue;
            String destination = o.optString("destinationName", o.optString("towards", "Southbound"));
            result.add(new Train(seconds, Math.max(0, (int)Math.ceil(seconds / 60.0)), destination, o.optString("platformName", ""), o.optString("currentLocation", ""), ""));
        }
        Collections.sort(result, Comparator.comparingInt(a -> a.seconds));
        if (result.size() > 8) result = new ArrayList<>(result.subList(0, 8));
        return new BoardData(s, result, fetchLineStatus(), System.currentTimeMillis(), false, null);
    }

    private static BoardData fetchNationalRail(BoardSpec s) throws Exception {
        String endpoint = "https://huxley2.azurewebsites.net/departures/" + s.from + "/to/" + s.to + "/10?expand=true";
        JSONObject root = new JSONObject(get(endpoint, "LondonRailBoard/1.0"));
        JSONArray services = root.optJSONArray("trainServices");
        List<Train> result = new ArrayList<>();
        long now = System.currentTimeMillis();
        if (services != null) {
            for (int i = 0; i < services.length(); i++) {
                JSONObject o = services.getJSONObject(i);
                String etd = o.optString("etd", "");
                String std = o.optString("std", "");
                String platform = o.optString("platform", "");
                String destination = destinationName(o, s.to);
                int minutes = minutesFromEtd(etd, std, now);
                int seconds = minutes < 0 ? 999999 : minutes * 60;
                if (minutes >= 0) result.add(new Train(seconds, minutes, destination, platform, etd, std));
            }
        }
        Collections.sort(result, Comparator.comparingInt(a -> a.seconds));
        if (result.size() > 8) result = new ArrayList<>(result.subList(0, 8));
        String nrcc = root.optString("nrccMessages", "");
        String status = nrcc == null || nrcc.trim().isEmpty() ? "NATIONAL RAIL: LIVE DEPARTURES" : "NATIONAL RAIL: " + nrcc.replaceAll("<[^>]+>", " ").trim();
        return new BoardData(s, result, status, now, false, null);
    }

    private static String destinationName(JSONObject o, String fallback) {
        try {
            JSONArray d = o.optJSONArray("destination");
            if (d != null && d.length() > 0) return d.getJSONObject(0).optString("locationName", fallback);
        } catch (Exception ignored) { }
        return fallback;
    }

    private static int minutesFromEtd(String etd, String std, long now) {
        if (etd == null) etd = "";
        if (etd.equalsIgnoreCase("On time") || etd.equalsIgnoreCase("Delayed") || etd.equalsIgnoreCase("Starts here")) etd = std;
        if (etd.equalsIgnoreCase("Cancelled") || etd.trim().isEmpty()) return -1;
        try {
            SimpleDateFormat fmt = new SimpleDateFormat("HH:mm", Locale.UK);
            fmt.setTimeZone(TimeZone.getTimeZone("Europe/London"));
            Date parsed = fmt.parse(etd);
            SimpleDateFormat day = new SimpleDateFormat("yyyy-MM-dd ", Locale.UK);
            day.setTimeZone(TimeZone.getTimeZone("Europe/London"));
            Date full = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.UK).parse(day.format(new Date(now)) + fmt.format(parsed));
            long diff = full.getTime() - now;
            if (diff < -10 * 60_000L) diff += 24 * 60 * 60_000L;
            return Math.max(0, (int)Math.ceil(diff / 60_000.0));
        } catch (Exception e) { return -1; }
    }

    private static String fetchLineStatus() {
        try {
            JSONArray arr = new JSONArray(get("https://api.tfl.gov.uk/Line/metropolitan/Status", "LondonRailBoard/1.0"));
            JSONArray statuses = arr.getJSONObject(0).optJSONArray("lineStatuses");
            JSONObject st = statuses.getJSONObject(0);
            String desc = st.optString("statusSeverityDescription", "Live service");
            String reason = st.optString("reason", "");
            String message = "METROPOLITAN LINE: " + desc.toUpperCase(Locale.UK);
            if (!reason.trim().isEmpty() && !desc.equalsIgnoreCase("Good Service")) message += " - " + reason.toUpperCase(Locale.UK);
            return message;
        } catch (Exception ignored) { return "METROPOLITAN LINE: LIVE SERVICE"; }
    }

    private static String get(String url, String agent) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(7000); conn.setReadTimeout(7000);
        conn.setRequestProperty("Accept", "application/json"); conn.setRequestProperty("User-Agent", agent);
        int code = conn.getResponseCode();
        if (code < 200 || code >= 300) throw new Exception("Live data API " + code);
        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close(); conn.disconnect(); return sb.toString();
    }

    private static boolean isOnline(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception ignored) { return true; }
    }

    static String hhmm(long when) { SimpleDateFormat fmt = new SimpleDateFormat("HH:mm", Locale.UK); fmt.setTimeZone(TimeZone.getTimeZone("Europe/London")); return fmt.format(new Date(when)); }
    static String cleanDestination(String destination) { if (destination == null || destination.trim().isEmpty()) return "TRAIN"; return destination.replace(" Underground Station", "").replace(" Rail Station", "").replace("London ", "").trim(); }
    static String rowText(Train t) { String body = cleanDestination(t.destination).toUpperCase(Locale.UK); if (t.scheduled != null && !t.scheduled.isEmpty()) body += "     " + t.scheduled; if (t.platform != null && !t.platform.isEmpty()) body += "     PLAT " + t.platform.toUpperCase(Locale.UK).replace("PLATFORM", "").trim(); if (t.currentLocation != null && !t.currentLocation.isEmpty() && !t.currentLocation.contains(":")) body += "     " + t.currentLocation.toUpperCase(Locale.UK); return body; }
    static String dueText(Train t) { return t.minutes <= 0 ? "DUE" : t.minutes + "m"; }
    static String ticker(BoardData data) { StringBuilder sb = new StringBuilder(data.status == null ? "LIVE SERVICE" : data.status); for (int i = 0; i < Math.min(3, data.trains.size()); i++) { Train t = data.trains.get(i); sb.append("     NEXT ").append(i + 1).append(": ").append(cleanDestination(t.destination).toUpperCase(Locale.UK)).append(" ").append(t.minutes <= 0 ? "DUE" : "IN " + t.minutes + " MIN"); } if (data.fromCache) sb.append("     SHOWING CACHED RESULTS"); sb.append("     TAP TO REFRESH"); return sb.toString(); }

    static final class BoardSpec { final String id,title,subtitle,from,to; final boolean isTfl; BoardSpec(String id,String title,String subtitle,String from,String to,boolean isTfl){this.id=id;this.title=title;this.subtitle=subtitle;this.from=from;this.to=to;this.isTfl=isTfl;} }
    static final class Train { final int seconds, minutes; final String destination, platform, currentLocation, scheduled; Train(int seconds,int minutes,String destination,String platform,String currentLocation,String scheduled){this.seconds=seconds;this.minutes=minutes;this.destination=destination;this.platform=platform;this.currentLocation=currentLocation;this.scheduled=scheduled;} }
    static final class BoardData { final BoardSpec spec; final List<Train> trains; final String status; final long fetchedAt; final boolean fromCache; final String error; BoardData(BoardSpec spec,List<Train> trains,String status,long fetchedAt,boolean fromCache,String error){this.spec=spec;this.trains=trains==null?new ArrayList<>():trains;this.status=status;this.fetchedAt=fetchedAt;this.fromCache=fromCache;this.error=error;} BoardData withCachedFlag(boolean flag){return new BoardData(spec,trains,status,fetchedAt,flag,error);} }
}
