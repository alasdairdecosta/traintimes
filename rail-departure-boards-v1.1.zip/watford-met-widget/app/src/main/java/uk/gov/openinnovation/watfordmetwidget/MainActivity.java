package uk.gov.openinnovation.watfordmetwidget;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends android.app.Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private LinearLayout boards;
    private boolean running;
    private final String[] routes = { TflClient.ROUTE_WATFORD, TflClient.ROUTE_PMR_VIC, TflClient.ROUTE_VIC_PMR };

    private final Runnable refresher = new Runnable() { @Override public void run() { refreshAll(false); if (running) handler.postDelayed(this, 30_000L); } };

    @Override protected void onCreate(Bundle b) { super.onCreate(b); buildUi(); refreshAll(false); }
    @Override protected void onResume() { super.onResume(); running = true; handler.postDelayed(refresher, 30_000L); }
    @Override protected void onPause() { super.onPause(); running = false; handler.removeCallbacks(refresher); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(Color.rgb(5,5,5));
        boards = new LinearLayout(this); boards.setOrientation(LinearLayout.VERTICAL); boards.setPadding(dp(16), dp(14), dp(16), dp(12));
        scroll.addView(boards); setContentView(scroll); boards.setOnClickListener(v -> refreshAll(true));
    }

    private void refreshAll(boolean force) {
        boards.removeAllViews();
        for (String r : routes) addLoadingBoard(TflClient.spec(r));
        executor.execute(() -> {
            TflClient.BoardData[] data = new TflClient.BoardData[routes.length];
            for (int i = 0; i < routes.length; i++) {
                try { data[i] = TflClient.loadBoard(getApplicationContext(), routes[i], force); }
                catch (Exception e) {
                    TflClient.BoardData cached = TflClient.readCache(getApplicationContext(), routes[i]);
                    data[i] = cached != null ? cached.withCachedFlag(true) : new TflClient.BoardData(TflClient.spec(routes[i]), null, "LIVE BOARD UNAVAILABLE", System.currentTimeMillis(), false, e.getMessage());
                }
            }
            runOnUiThread(() -> renderAll(data));
            updateAllWidgets();
        });
    }

    private void updateAllWidgets() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        new WatfordMetWidgetProvider().updateWidgets(this, manager, manager.getAppWidgetIds(new ComponentName(this, WatfordMetWidgetProvider.class)), false);
        new PeckhamToVictoriaWidgetProvider().updateWidgets(this, manager, manager.getAppWidgetIds(new ComponentName(this, PeckhamToVictoriaWidgetProvider.class)), false);
        new VictoriaToPeckhamWidgetProvider().updateWidgets(this, manager, manager.getAppWidgetIds(new ComponentName(this, VictoriaToPeckhamWidgetProvider.class)), false);
    }

    private void renderAll(TflClient.BoardData[] data) { boards.removeAllViews(); for (TflClient.BoardData d : data) addBoard(d); }
    private void addLoadingBoard(TflClient.BoardSpec spec) { addBoard(new TflClient.BoardData(spec, null, "CHECKING LIVE DEPARTURE BOARD", System.currentTimeMillis(), false, null)); }

    private void addBoard(TflClient.BoardData data) {
        int amber = Color.rgb(255,176,0), yellow = Color.rgb(255,216,77), dim = Color.rgb(169,120,0), panel = Color.rgb(10,10,8);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(0,0,0,dp(20)); boards.addView(root, new LinearLayout.LayoutParams(-1,-2));
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); root.addView(top, new LinearLayout.LayoutParams(-1,-2));
        TextView title = boardText(data.spec.title, 28, yellow, true); title.setLetterSpacing(0.12f); top.addView(title, new LinearLayout.LayoutParams(0,-2,1));
        top.addView(boardText(TflClient.hhmm(data.fetchedAt), 14, dim, true));
        View bar = new View(this); bar.setBackgroundColor(data.spec.isTfl ? Color.rgb(155,0,86) : Color.rgb(255,176,0)); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(5)); bp.setMargins(0,dp(6),0,dp(7)); root.addView(bar,bp);
        TextView sub = boardText(data.spec.subtitle, 13, dim, true); sub.setLetterSpacing(0.12f); root.addView(sub);
        TextView ticker = boardText(TflClient.ticker(data) + "     " + TflClient.ticker(data), 15, amber, true); ticker.setSingleLine(true); ticker.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE); ticker.setMarqueeRepeatLimit(-1); ticker.setSelected(true); LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,-2); tp.setMargins(0,dp(6),0,dp(8)); root.addView(ticker,tp);
        if (data.trains.isEmpty()) { addRow(root, "--", data.error == null ? "NO LIVE TRAINS FOUND" : "LIVE BOARD UNAVAILABLE", true, panel, yellow); addRow(root, "--", "TAP TO TRY AGAIN", false, panel, yellow); }
        else for (int i=0;i<Math.min(3,data.trains.size());i++) addRow(root, TflClient.dueText(data.trains.get(i)), TflClient.rowText(data.trains.get(i)), i==0, panel, yellow);
        TextView foot = boardText((data.fromCache ? "Cached " : "Updated ") + TflClient.hhmm(data.fetchedAt) + " · tap anywhere to refresh · widgets update every 15 min", 11, dim, false); foot.setGravity(Gravity.RIGHT); LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1,-2); fp.setMargins(0,dp(7),0,0); root.addView(foot, fp);
    }

    private void addRow(LinearLayout root, String due, String body, boolean first, int panel, int yellow) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(8),dp(8),dp(8),dp(8)); row.setBackgroundColor(panel); LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1,-2); rp.setMargins(0, first ? 0 : dp(7), 0, 0); root.addView(row,rp);
        TextView mins = boardText(due, first ? 24 : 21, yellow, true); mins.setGravity(Gravity.CENTER); row.addView(mins, new LinearLayout.LayoutParams(dp(76), -1));
        TextView text = boardText(body, first ? 24 : 21, yellow, true); text.setSingleLine(true); text.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE); text.setMarqueeRepeatLimit(-1); text.setSelected(true); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(12),0,0,0); row.addView(text,lp);
    }
    private TextView boardText(String text, int sp, int color, boolean bold) { TextView v = new TextView(this); v.setText(text); v.setTextColor(color); v.setTextSize(sp); v.setTypeface(Typeface.MONOSPACE, bold ? Typeface.BOLD : Typeface.NORMAL); v.setShadowLayer(5f,0f,0f,Color.rgb(255,176,0)); return v; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
