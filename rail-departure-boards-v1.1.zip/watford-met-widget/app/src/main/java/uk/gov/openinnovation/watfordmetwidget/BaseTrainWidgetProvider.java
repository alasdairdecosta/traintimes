package uk.gov.openinnovation.watfordmetwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class BaseTrainWidgetProvider extends AppWidgetProvider {
    static final String ACTION_REFRESH_PREFIX = "uk.gov.openinnovation.watfordmetwidget.REFRESH.";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    protected abstract String routeId();
    protected abstract Class<?> providerClass();

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) { updateWidgets(context, manager, ids, false); }
    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if ((ACTION_REFRESH_PREFIX + routeId()).equals(intent.getAction())) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, providerClass()));
            updateWidgets(context, manager, ids, true);
        }
    }
    void updateWidgets(Context context, AppWidgetManager manager, int[] ids, boolean force) {
        if (ids == null || ids.length == 0) return;
        TflClient.BoardSpec spec = TflClient.spec(routeId());
        for (int id : ids) manager.updateAppWidget(id, loadingViews(context, spec));
        Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            RemoteViews views;
            try { views = viewsForData(appContext, TflClient.loadBoard(appContext, routeId(), force)); }
            catch (Exception e) {
                TflClient.BoardData cached = TflClient.readCache(appContext, routeId());
                views = cached != null ? viewsForData(appContext, cached.withCachedFlag(true)) : errorViews(appContext, spec, e.getMessage());
            }
            for (int id : ids) manager.updateAppWidget(id, views);
        });
    }
    private RemoteViews loadingViews(Context context, TflClient.BoardSpec spec) {
        RemoteViews views = baseViews(context, spec);
        views.setTextViewText(R.id.clock, "LIVE");
        views.setTextViewText(R.id.ticker, "CHECKING LIVE DEPARTURE BOARD     CHECKING LIVE DEPARTURE BOARD");
        setRow(views, 1, "--", "FETCHING NEXT TRAINS"); setRow(views, 2, "--", ""); setRow(views, 3, "--", "");
        views.setTextViewText(R.id.footer, "Fetching live arrivals...");
        return views;
    }
    private RemoteViews viewsForData(Context context, TflClient.BoardData data) {
        RemoteViews views = baseViews(context, data.spec);
        views.setTextViewText(R.id.clock, TflClient.hhmm(data.fetchedAt));
        views.setTextViewText(R.id.ticker, TflClient.ticker(data));
        if (data.trains.isEmpty()) {
            setRow(views, 1, "--", "NO LIVE TRAINS FOUND"); setRow(views, 2, "--", "TRY AGAIN SHORTLY"); setRow(views, 3, "--", "");
        } else {
            for (int i = 0; i < 3; i++) if (i < data.trains.size()) setRow(views, i + 1, TflClient.dueText(data.trains.get(i)), TflClient.rowText(data.trains.get(i))); else setRow(views, i + 1, "--", "");
        }
        views.setTextViewText(R.id.footer, (data.fromCache ? "Cached " : "Updated ") + TflClient.hhmm(data.fetchedAt) + " · tap to refresh");
        return views;
    }
    private RemoteViews errorViews(Context context, TflClient.BoardSpec spec, String message) {
        RemoteViews views = baseViews(context, spec);
        views.setTextViewText(R.id.clock, "--:--"); views.setTextViewText(R.id.ticker, "SERVICE INFORMATION COULD NOT BE LOADED     TAP TO TRY AGAIN");
        setRow(views, 1, "--", "LIVE BOARD UNAVAILABLE"); setRow(views, 2, "--", "TAP TO TRY AGAIN"); setRow(views, 3, "--", "");
        views.setTextViewText(R.id.footer, message == null ? "Network error" : message); return views;
    }
    private RemoteViews baseViews(Context context, TflClient.BoardSpec spec) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.train_widget);
        views.setTextViewText(R.id.title, spec.title); views.setTextViewText(R.id.subtitle, spec.subtitle);
        Intent refresh = new Intent(context, providerClass()).setAction(ACTION_REFRESH_PREFIX + routeId());
        PendingIntent pi = PendingIntent.getBroadcast(context, routeId().hashCode(), refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pi);
        selectForMarquee(views, R.id.ticker); selectForMarquee(views, R.id.train1); selectForMarquee(views, R.id.train2); selectForMarquee(views, R.id.train3);
        return views;
    }
    private static void selectForMarquee(RemoteViews views, int id) { views.setBoolean(id, "setSelected", true); }
    private static void setRow(RemoteViews views, int row, String due, String body) { if (row == 1) { views.setTextViewText(R.id.min1, due); views.setTextViewText(R.id.train1, body); } else if (row == 2) { views.setTextViewText(R.id.min2, due); views.setTextViewText(R.id.train2, body); } else { views.setTextViewText(R.id.min3, due); views.setTextViewText(R.id.train3, body); } }
}
