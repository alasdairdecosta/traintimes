package uk.gov.openinnovation.watfordmetwidget;
public class VictoriaToPeckhamWidgetProvider extends BaseTrainWidgetProvider { protected String routeId(){return TflClient.ROUTE_VIC_PMR;} protected Class<?> providerClass(){return VictoriaToPeckhamWidgetProvider.class;} }
