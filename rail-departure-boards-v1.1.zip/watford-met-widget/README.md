# Rail Departure Boards v1.1

Android app + home-screen widgets for three London departure boards:

- Watford Met southbound Metropolitan line
- Peckham Rye to London Victoria
- London Victoria to Peckham Rye

## Battery approach

The app is deliberately conservative:

- Widgets update every 15 minutes via Android's normal app-widget scheduler.
- Widgets can be manually refreshed by tapping them.
- The full-screen app refreshes every 30 seconds only while it is open.
- There is no permanent background service.
- There are no one-minute exact alarms.
- There is no GPS/location use.
- Results are cached and reused if a feed fails.
- Network calls are throttled to avoid repeat fetches within 20 seconds.

This gives the animated departure-board feel without the battery cost of polling every minute all day.

## Animation / display behaviour

Android home-screen widgets cannot run arbitrary continuous animations like a normal app can. For that reason:

- Widget rows and ticker use Android marquee behaviour where the launcher supports it.
- Widgets are designed to feel live, but not to constantly wake the phone.
- The full app is where the smoother live-board effect runs while the screen is already on.

## Data sources

- TfL Unified API for Watford Metropolitan line arrivals and Metropolitan line status.
- Huxley JSON proxy for National Rail Darwin departures for Peckham Rye and Victoria.

## Phone-only build route

The easiest phone-only route is GitHub Actions:

1. Create a GitHub repository.
2. Upload `rail-departure-boards-v1.1.zip` to the repo root.
3. Create `.github/workflows/build-apk.yml` using the supplied `build-apk-from-zip-v1.1.yml` file.
4. Run the workflow from the Actions tab.
5. Download the APK artifact and install `app-debug.apk` on Android.

## Notes

This is an unsigned debug APK flow for personal installation. A proper Play Store or long-term release build would use a signed release APK/AAB.
