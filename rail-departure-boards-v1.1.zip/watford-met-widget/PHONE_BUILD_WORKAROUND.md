# Phone-only APK build workaround

The easiest route now is GitHub Actions, because AndroidIDE was awkward on this device.

## From your phone

1. Make a new GitHub repo.
2. Upload all files from this project folder. The `.github/workflows/build-apk.yml` file must be included.
3. Go to **Actions**.
4. Select **Build APK**.
5. Tap **Run workflow**.
6. When it finishes, open the run and download **rail-departure-boards-debug-apk**.
7. Extract the downloaded artifact; inside is `app-debug.apk`.
8. Tap it to install.

## Add widgets

After installing:

1. Long-press your home screen.
2. Tap **Widgets**.
3. Add one or more of:
   - Watford Met southbound
   - Peckham Rye to Victoria
   - Victoria to Peckham Rye

Tap a widget to refresh it.
